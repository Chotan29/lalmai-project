<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Registration</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css"
        integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }

        .top-navbar {
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 10px 0;
            margin-bottom: 20px;
        }

        .top-navbar .navbar-menu {
            display: flex;
            width: 100%;
        }

        .top-navbar .nav.navbar-nav {
            display: flex;
            flex-direction: row;
            list-style: none;
            padding: 0;
            margin: 0;
            width: 100%;
            justify-content: center;
        }

        .top-navbar .nav-item {
            display: inline-block;
            margin-left: 15px;
        }

        .top-navbar .nav-link {
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .top-navbar .nav-link:hover {
            background-color: #f8f9fa;
            color: #1e5799;
        }

        .top-navbar .nav-link i {
            margin-right: 5px;
        }

        .registration-container {
            max-width: 1200px;
            margin: 30px auto;
            background: #fff;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .registration-header {
            padding: 30px;
            background: linear-gradient(135deg, #1e5799 0%, #207cca 51%, #2989d8 100%);
            color: white;
            text-align: center;
            position: relative;
        }

        .logo-container {
            margin-bottom: 20px;
        }

        .logo-container img {
            max-height: 100px;
            max-width: 100%;
        }

        .institution-info h1 {
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .institution-info h2 {
            font-size: 22px;
            font-weight: 500;
            margin-top: 20px;
            color: #fff;
        }

        .institution-details {
            font-size: 14px;
            opacity: 0.9;
            margin-bottom: 0;
        }

        .guidelines-container {
            padding: 20px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #eee;
        }

        .accordion {
            margin-bottom: 0;
        }

        .accordion-toggle {
            display: none;
        }

        .accordion-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 15px;
            background-color: #e9ecef;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
        }

        .accordion-header:hover {
            background-color: #dee2e6;
        }

        .accordion-icon {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-right: 2px solid #333;
            border-bottom: 2px solid #333;
            transform: rotate(45deg);
            transition: transform 0.2s ease;
        }

        .accordion-toggle:checked~.accordion-header .accordion-icon {
            transform: rotate(-135deg);
        }

        .accordion-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
            padding: 0 15px;
        }

        .accordion-toggle:checked~.accordion-content {
            max-height: 1000px;
            padding: 15px;
        }

        .registration-form-container {
            padding: 30px;
        }

        .nav-tabs {
            border-bottom: 2px solid #dee2e6;
            margin-bottom: 25px;
        }

        .nav-tabs .nav-link {
            border: none;
            color: #495057;
            font-weight: 500;
            padding: 12px 20px;
            border-radius: 0;
        }

        .nav-tabs .nav-link:hover {
            border-color: transparent;
            color: #007bff;
        }

        .nav-tabs .nav-link.active {
            color: #007bff;
            background-color: transparent;
            border-bottom: 2px solid #007bff;
        }

        .tab-pane {
            padding: 15px 0;
        }

        .form-section {
            margin-bottom: 30px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        .form-navigation {
            margin-top: 30px;
        }

        .preview-image-container {
            width: 150px;
            height: 150px;
            border: 1px solid #ddd;
            border-radius: 4px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fa;
        }

        .preview-image {
            max-width: 100%;
            max-height: 100%;
        }

        .registration-closed,
        .registration-unavailable {
            text-align: center;
            padding: 50px 20px;
        }

        .registration-closed h1,
        .registration-unavailable h1 {
            color: #dc3545;
            margin-bottom: 30px;
        }

        .closed-message {
            max-width: 800px;
            margin: 0 auto 30px;
            padding: 20px;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
        }

        .contact-info {
            margin-top: 20px;
            font-size: 14px;
        }

        .btn-next,
        .btn-prev {
            min-width: 120px;
        }

        .is-invalid {
            border-color: #dc3545;
        }

        .invalid-feedback {
            display: block;
            color: #dc3545;
            font-size: 0.875em;
        }

        .custom-file-label::after {
            content: "Browse";
        }

        .upper {
            text-transform: uppercase;
        }

        .label-warning {
            background-color: #f39c12;
            padding: 5px 10px;
           outa border-radius: 4px;
            color: white;
            display: inline-block;
            margin-bottom: 10px;
        }

        .hr-8 {
            height: 1px;
            margin: 8px 0;
            background-color: #ddd;
        }

        @media (max-width: 768px) {
            .registration-header {
                padding: 20px;
            }

            .institution-info h1 {
                font-size: 22px;
            }

            .institution-info h2 {
                font-size: 18px;
            }

            .registration-form-container {
                padding: 20px;
            }

            .nav-tabs .nav-link {
                padding: 8px 12px;
                font-size: 14px;
            }
        }
    </style>
</head>

<body>
    <div class="top-navbar">
        <div class="container">
            <nav role="navigation" class="navbar-menu">
                <ul class="nav navbar-nav">
                    @if (isset($generalSetting) && $generalSetting->public_registration == 1)
                        <li class="nav-item">
                            <a href="{{ route('online-registration.registration') }}" class="nav-link">
                                <i class="fas fa-user"></i> Online Registration
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('online-registration.find') }}" class="nav-link">
                                <i class="fas fa-search"></i> Find & Print Registration
                            </a>
                        </li>
                    @endif
                    <li class="nav-item">
                        <a href="{{ route('login') }}" target="_blank" class="nav-link">
                            <i class="fas fa-sign-in-alt"></i> Login
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('web.home') }}" target="_blank" class="nav-link">
                            <i class="fas fa-globe"></i> WebPortal
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>

    @if (isset($data['registration_setting']) && $data['registration_setting'] != null)
        @if (
            $data['registration_setting']->status == 'active' &&
                date('Y-m-d') >= $data['registration_setting']->start_date &&
                $data['registration_setting']->end_date >= date('Y-m-d'))
            <div class="registration-container">
                <div class="registration-header">
                    <div class="logo-container">
                        @if ($data['registration_setting']->logo !== '')
                            <img src="{{ asset('images/setting/online-registration/' . $data['registration_setting']->logo) }}"
                                alt="Institution Logo">
                        @else
                            <img src="{{ asset('images/setting/general/' . $generalSetting->logo) }}"
                                alt="Institution Logo">
                        @endif
                    </div>
                    <div class="institution-info">
                        <h1>{{ $generalSetting->institute ?? 'EduFirm Web Portal Online Registration' }}</h1>
                        <p class="institution-details">
                            {{ $generalSetting->address ?? '' }},
                            {{ $generalSetting->phone ?? '' }},
                            {{ $generalSetting->email ?? '' }}
                        </p>
                        <h2>{{ $data['registration_setting']->title ?? 'ONLINE APPLICATION FOR ADMISSION' }}</h2>
                    </div>
                </div>

                @if (isset($data['registration_setting']->registration_guidelines))
                    <div class="guidelines-container">
                        <div class="accordion">
                            <input type="checkbox" id="guidelines-toggle" class="accordion-toggle">
                            <label for="guidelines-toggle" class="accordion-header">
                                <span>Registration Guidelines</span>
                                <i class="accordion-icon"></i>
                            </label>
                            <div class="accordion-content">
                                {!! $data['registration_setting']->registration_guidelines !!}
                            </div>
                        </div>
                    </div>
                @endif

                <div class="registration-form-container">
                    @include('includes.validation_error_messages')

                    {!! Form::open([
                        'route' => $base_route . '.register',
                        'method' => 'POST',
                        'class' => 'registration-form',
                        'id' => 'validation-form',
                        'enctype' => 'multipart/form-data',
                    ]) !!}

                    <!-- Tab navigation -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item" id="generalInfoTab">
                            <a class="nav-link active" data-toggle="tab" href="#generalInfo" role="tab">
                                <i class="fa fa-user"></i> General Information
                            </a>
                        </li>
                        <li class="nav-item" id="academicInfoTab">
                            <a class="nav-link" data-toggle="tab" href="#academicInfo" role="tab">
                                <i class="fa fa-certificate"></i> Academic Information
                            </a>
                        </li>
                        <li class="nav-item" id="profileImageTab">
                            <a class="nav-link" data-toggle="tab" href="#profileImage" role="tab">
                                <i class="fa fa-image"></i> Profile Image
                            </a>
                        </li>
                        @if (isset($data['annexures']) && count($data['annexures']) > 0)
                            <li class="nav-item" id="annexureTab">
                                <a class="nav-link" data-toggle="tab" href="#annexure" role="tab">
                                    <i class="fa fa-list"></i> Annexure
                                </a>
                            </li>
                        @endif
                        @if ($data['registration_setting']->rules_status == '1')
                            <li class="nav-item" id="rulesTab">
                                <a class="nav-link" data-toggle="tab" href="#rules" role="tab">
                                    <i class="fa fa-file-text"></i> Rules
                                </a>
                            </li>
                        @endif
                        @if ($data['registration_setting']->agreement_status == '1')
                            <li class="nav-item" id="agreementTab">
                                <a class="nav-link" data-toggle="tab" href="#agreement" role="tab">
                                    <i class="fa fa-file-contract"></i> Agreement
                                </a>
                            </li>
                        @endif
                    </ul>

                    <div class="tab-content">
                        <!-- General Info Tab -->
                        <div class="tab-pane fade show active" id="generalInfo" role="tabpanel">
                            <div class="form-section">
                                <h3 class="section-title"><i class="fa fa-info-circle"></i> Enrollment Information
                                </h3>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Session <span class="text-danger">*</span></label>
                                            {!! Form::select('batch', $data['batch'], null, ['class' => 'form-control', 'required', 'readonly']) !!}
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Faculty/Program <span class="text-danger">*</span></label>
                                            <select name="faculty" class="form-control"
                                                onChange="loadSemesters(this)" required>
                                                @foreach ($data['faculties'] as $key => $faculty)
                                                    <option value="{{ $key }}">{{ $faculty }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Semester/Section <span class="text-danger">*</span></label>
                                            <select id="semester" name="semester" required
                                                onChange="loadSubject(this)" class="form-control semester">
                                                <option value="">Select Sem./Sec.</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-section">
                                <h3 class="section-title"><i class="fa fa-user"></i> Personal Information</h3>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>First Name <span class="text-danger">*</span></label>
                                            <input type="text" name="first_name" class="form-control upper"
                                                required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Middle Name</label>
                                            <input type="text" name="middle_name" class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Last Name <span class="text-danger">*</span></label>
                                            <input type="text" name="last_name" class="form-control upper"
                                                required>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Date of Birth <span class="text-danger">*</span></label>
                                            <input type="date" name="date_of_birth"
                                                class="form-control date-picker input-mask-date" required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Gender <span class="text-danger">*</span></label>
                                            <select name="gender" class="form-control" required>
                                                <option value="">Select Gender</option>
                                                <option value="male">Male</option>
                                                <option value="female">Female</option>
                                                <option value="other">Other</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Blood Group</label>
                                            <select name="blood_group" class="form-control">
                                                <option value="">Select Blood Group</option>
                                                <option value="A+">A+</option>
                                                <option value="A-">A-</option>
                                                <option value="B+">B+</option>
                                                <option value="B-">B-</option>
                                                <option value="AB+">AB+</option>
                                                <option value="AB-">AB-</option>
                                                <option value="O+">O+</option>
                                                <option value="O-">O-</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Nationality <span class="text-danger">*</span></label>
                                            <input type="text" name="nationality" class="form-control upper"
                                                required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>National ID 1</label>
                                            <input type="text" name="national_id_1" class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>National ID 2</label>
                                            <input type="text" name="national_id_2" class="form-control upper">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>National ID 3</label>
                                            <input type="text" name="national_id_3" class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>National ID 4</label>
                                            <input type="text" name="national_id_4" class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Mother Tongue</label>
                                            <input type="text" name="mother_tongue" class="form-control upper">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Religion</label>
                                            <input type="text" name="religion" class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Caste</label>
                                            <input type="text" name="caste" class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Email <span class="text-danger">*</span></label>
                                            <input type="email" name="email" class="form-control" required>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-section">
                                <h3 class="section-title"><i class="fa fa-phone"></i> Contact Information</h3>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Home Phone</label>
                                            <input type="text" name="home_phone"
                                                class="form-control input-mask-phone">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Mobile 1 <span class="text-danger">*</span></label>
                                            <input type="text" name="mobile_1"
                                                class="form-control input-mask-mobile" required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Mobile 2</label>
                                            <input type="text" name="mobile_2"
                                                class="form-control input-mask-mobile">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-section">
                                <h3 class="section-title"><i class="fa fa-map-marker"></i> Address Information</h3>
                                <div class="label label-warning arrowed-in arrowed-right arrowed">Permanent Address
                                </div>
                                <hr class="hr-8">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label>Address <span class="text-danger">*</span></label>
                                            <input type="text" name="address" class="form-control upper" required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>State <span class="text-danger">*</span></label>
                                            <input type="text" name="state" class="form-control upper" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Postal Code <span class="text-danger">*</span></label>
                                            <input type="text" name="postal_code" class="form-control upper"
                                                required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Country <span class="text-danger">*</span></label>
                                            <input type="text" name="country" class="form-control upper" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="label label-warning arrowed-in arrowed-right arrowed">Temporary Address
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" name="permanent_address_copier"
                                        id="permanent_address_copier" class="form-check-input"
                                        onclick="CopyAddress(this.form)">
                                    <label class="form-check-label" for="permanent_address_copier">Temporary Address
                                        Same As Permanent Address</label>
                                </div>
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label>Temporary Address</label>
                                            <input type="text" name="temp_address" class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Temporary State</label>
                                            <input type="text" name="temp_state" class="form-control upper">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Temporary Postal Code</label>
                                            <input type="text" name="temp_postal_code" class="form-control upper">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-section">
                                <h3 class="section-title"><i class="fa fa-users"></i> Parent Information</h3>

                                <div class="label label-warning arrowed-in arrowed-right arrowed">Father's Details
                                </div>
                                <hr class="hr-8">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>First Name <span class="text-danger">*</span></label>
                                            <input type="text" name="father_first_name" class="form-control upper"
                                                required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Middle Name</label>
                                            <input type="text" name="father_middle_name"
                                                class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Last Name <span class="text-danger">*</span></label>
                                            <input type="text" name="father_last_name" class="form-control upper"
                                                required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Eligibility</label>
                                            <input type="text" name="father_eligibility"
                                                class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Occupation</label>
                                            <input type="text" name="father_occupation"
                                                class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Office</label>
                                            <input type="text" name="father_office" class="form-control upper">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Office Number</label>
                                            <input type="text" name="father_office_number"
                                                class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Residence Number</label>
                                            <input type="text" name="father_residence_number"
                                                class="form-control input-mask-mobile">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Mobile 1</label>
                                            <input type="text" name="father_mobile_1"
                                                class="form-control input-mask-mobile">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Mobile 2</label>
                                            <input type="text" name="father_mobile_2"
                                                class="form-control input-mask-mobile">
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" name="father_email" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <div class="label label-warning arrowed-in arrowed-right arrowed">Mother's Details
                                </div>
                                <hr class="hr-8">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>First Name <span class="text-danger">*</span></label>
                                            <input type="text" name="mother_first_name" class="form-control upper"
                                                required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Middle Name</label>
                                            <input type="text" name="mother_middle_name"
                                                class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Last Name <span class="text-danger">*</span></label>
                                            <input type="text" name="mother_last_name" class="form-control upper"
                                                required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Eligibility</label>
                                            <input type="text" name="mother_eligibility"
                                                class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Occupation</label>
                                            <input type="text" name="mother_occupation"
                                                class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Office</label>
                                            <input type="text" name="mother_office" class="form-control upper">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Office Number</label>
                                            <input type="text" name="mother_office_number"
                                                class="form-control upper">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Residence Number</label>
                                            <input type="text" name="mother_residence_number"
                                                class="form-control input-mask-mobile">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Mobile 1</label>
                                            <input type="text" name="mother_mobile_1"
                                                class="form-control input-mask-mobile">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Mobile 2</label>
                                            <input type="text" name="mother_mobile_2"
                                                class="form-control input-mask-mobile">
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" name="mother_email" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-section">
                                <h3 class="section-title"><i class="fa fa-user-shield"></i> Guardian Information</h3>
                                <div class="form-group">
                                    <label>Guardian Is:</label>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="guardian_is"
                                            id="father_as_guardian" value="father_as_guardian"
                                            onclick="FatherAsGuardian(this.form)">
                                        <label class="form-check-label" for="father_as_guardian">Father</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="guardian_is"
                                            id="mother_as_guardian" value="mother_as_guardian"
                                            onclick="MotherAsGuardian(this.form)">
                                        <label class="form-check-label" for="mother_as_guardian">Mother</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="guardian_is"
                                            id="self_guardian" value="self_guardian"
                                            onclick="SelfGuardian(this.form)">
                                        <label class="form-check-label" for="self_guardian">Self</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="guardian_is"
                                            id="other_guardian" value="other_guardian"
                                            onclick="OtherGuardian(this.form)">
                                        <label class="form-check-label" for="other_guardian">Other</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="guardian_is"
                                            id="link_guardian" value="link_guardian"
                                            onclick="linkGuardian(this.form)">
                                        <label class="form-check-label" for="link_guardian">Link Guardian</label>
                                    </div>
                                </div>

                                <div id="guardian-detail">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>First Name <span class="text-danger">*</span></label>
                                                <input type="text" name="guardian_first_name"
                                                    class="form-control upper" required>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Middle Name</label>
                                                <input type="text" name="guardian_middle_name"
                                                    class="form-control upper">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Last Name <span class="text-danger">*</span></label>
                                                <input type="text" name="guardian_last_name"
                                                    class="form-control upper" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Eligibility</label>
                                                <input type="text" name="guardian_eligibility"
                                                    class="form-control upper">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Occupation</label>
                                                <input type="text" name="guardian_occupation"
                                                    class="form-control upper">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Office</label>
                                                <input type="text" name="guardian_office"
                                                    class="form-control upper">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Office Number</label>
                                                <input type="text" name="guardian_office_number"
                                                    class="form-control upper">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Residence Number</label>
                                                <input type="text" name="guardian_residence_number"
                                                    class="form-control input-mask-mobile">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Mobile 1 <span class="text-danger">*</span></label>
                                                <input type="text" name="guardian_mobile_1"
                                                    class="form-control input-mask-mobile" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Mobile 2</label>
                                                <input type="text" name="guardian_mobile_2"
                                                    class="form-control input-mask-mobile">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Email</label>
                                                <input type="email" name="guardian_email" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Relation <span class="text-danger">*</span></label>
                                                <input type="text" name="guardian_relation"
                                                    class="form-control upper" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Address <span class="text-danger">*</span></label>
                                                <input type="text" name="guardian_address"
                                                    class="form-control upper" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="link-guardian-detail" style="display: none;">
                                    <div class="form-group">
                                        <label>Find Guardian Using Name | Mobile Number | Email & Click on Link
                                            Now</label>
                                        <select name="guardian_link_id" class="form-control" style="width: 100%;">
                                            <option value="">Type Student Reg.No. or Guardians Name...</option>
                                        </select>
                                        <div class="text-right mt-2">
                                            <button type="button" class="btn btn-sm btn-primary"
                                                id="load-guardian-html-btn">
                                                <i class="fa fa-link"></i> Link Now
                                            </button>
                                        </div>
                                    </div>
                                    <div id="guardian_wrapper"></div>
                                </div>
                            </div>

                            <div class="form-navigation d-flex justify-content-between mt-4">
                                <div></div>
                                <button type="button" class="btn btn-primary btn-next"
                                    onclick="navigateTab('next')">
                                    Next <i class="fa fa-arrow-right ml-2"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Academic Info Tab -->
                        <div class="tab-pane fade" id="academicInfo" role="tabpanel">
                            <div class="form-section">
                                <h3 class="section-title"><i class="fa fa-book"></i> Subjects</h3>
                                <div id="subjects_wrapper">
                                    <!-- Subjects will be loaded here via AJAX -->
                                </div>
                            </div>

                            <div class="form-navigation d-flex justify-content-between mt-4">
                                <button type="button" class="btn btn-secondary btn-prev"
                                    onclick="navigateTab('prev')">
                                    <i class="fa fa-arrow-left mr-2"></i> Previous
                                </button>
                                <button type="button" class="btn btn-primary btn-next"
                                    onclick="navigateTab('next')">
                                    Next <i class="fa fa-arrow-right ml-2"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Profile Image Tab -->
                        <div class="tab-pane fade" id="profileImage" role="tabpanel">
                            <div class="form-section">
                                <h3 class="section-title"><i class="fa fa-camera"></i> Upload Student Photo</h3>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Upload Photo</label>
                                    <div class="col-md-6">
                                        <div class="custom-file">
                                            <input type="file" name="student_main_image" id="student_main_image"
                                                class="custom-file-input" onchange="previewImage(this)"
                                                accept="image/*" required>
                                            <label class="custom-file-label" for="student_main_image">Choose
                                                file</label>
                                        </div>
                                        <small class="form-text text-muted">Max file size: 2MB | Recommended
                                            dimensions: 300x300px</small>
                                    </div>

                                    <div class="col-md-3">
                                        <div id="imagePreview" class="preview-image-container">
                                            <img id="previewImage" src="{{ asset('images/default-user.png') }}"
                                                class="img-thumbnail preview-image">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-navigation d-flex justify-content-between mt-4">
                                <button type="button" class="btn btn-secondary btn-prev" onclick="navigateTab('prev')">
                                    <i class="fa fa-arrow-left mr-2"></i> Previous
                                </button>
                                <button type="button" class="btn btn-primary btn-next" onclick="navigateTab('next')">
                                    Next <i class="fa fa-arrow-right ml-2"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Annexure Tab -->
                        @if(isset($data['annexures']) && count($data['annexures']) > 0)
                        <div class="tab-pane fade" id="annexure" role="tabpanel">
                            <div class="form-section">
                                <h3 class="section-title"><i class="fa fa-list"></i> Annexure Documents</h3>
                                <div class="label label-warning arrowed-in arrowed-right arrowed">
                                    Details of Annexure & photo copy :
                                </div>
                                <hr class="hr-8">
                                <div class="row">
                                    @foreach($data['annexures'] as $annexure)
                                    <div class="col-md-6">
                                        <div class="form-check">
                                            <input type="checkbox" name="annexure[]" id="annexure_{{ $annexure->id }}"
                                                value="{{ $annexure->id }}" class="form-check-input">
                                            <label class="form-check-label" for="annexure_{{ $annexure->id }}">
                                                {{ $annexure->title }}
                                            </label>
                                        </div>
                                        <hr class="hr-2">
                                    </div>
                                    @endforeach
                                </div>
                            </div>

                            <div class="form-navigation d-flex justify-content-between mt-4">
                                <button type="button" class="btn btn-secondary btn-prev" onclick="navigateTab('prev')">
                                    <i class="fa fa-arrow-left mr-2"></i> Previous
                                </button>
                                <button type="button" class="btn btn-primary btn-next" onclick="navigateTab('next')">
                                    Next <i class="fa fa-arrow-right ml-2"></i>
                                </button>
                            </div>
                        </div>
                        @endif

                        <!-- Rules Tab -->
                        @if($data['registration_setting']->rules_status == '1')
                        <div class="tab-pane fade" id="rules" role="tabpanel">
                            <div class="form-section">
                                <h3 class="section-title"><i class="fa fa-file-text"></i> Registration Rules</h3>
                                <div class="rules-container"
                                     style="max-height: 300px; overflow-y: auto; border: 1px solid #ddd; padding: 15px; margin-bottom: 20px;">
                                    {!! $data['registration_setting']->rules !!}
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="agree_rules" name="agree_rules" required>
                                    <label class="form-check-label" for="agree_rules">
                                        I agree to abide by the rules and regulations mentioned above
                                    </label>
                                </div>
                            </div>

                            <div class="form-navigation d-flex justify-content-between mt-4">
                                <button type="button" class="btn btn-secondary btn-prev" onclick="navigateTab('prev')">
                                    <i class="fa fa-arrow-left mr-2"></i> Previous
                                </button>
                                <button type="button" class="btn btn-primary btn-next" onclick="navigateTab('next')">
                                    Next <i class="fa fa-arrow-right ml-2"></i>
                                </button>
                            </div>
                        </div>
                        @endif

                        <!-- Agreement Tab -->
                        @if($data['registration_setting']->agreement_status == '1')
                        <div class="tab-pane fade" id="agreement" role="tabpanel">
                            <div class="form-section">
                                <h3 class="section-title"><i class="fa fa-file-contract"></i> Registration Agreement</h3>
                                <div class="agreement-container"
                                     style="max-height: 300px; overflow-y: auto; border: 1px solid #ddd; padding: 15px; margin-bottom: 20px;">
                                    {!! $data['registration_setting']->agreement !!}
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="agree_terms" name="agree_terms" required>
                                    <label class="form-check-label" for="agree_terms">
                                        I agree to the terms and conditions mentioned above
                                    </label>
                                </div>
                            </div>

                            <div class="form-navigation d-flex justify-content-between mt-4">
                                <button type="button" class="btn btn-secondary btn-prev" onclick="navigateTab('prev')">
                                    <i class="fa fa-arrow-left mr-2"></i> Previous
                                </button>
                                <button type="submit" class="btn btn-success" name="add_student" id="add-student">
                                    <i class="fa fa-check"></i> Submit Application
                                </button>
                            </div>
                        </div>
                        @endif
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        @else
            <div class="registration-closed">
                <div class="closed-message">
                    {!! $data['registration_setting']->registration_close_message !!}
                </div>
                <div class="institution-info">
                    @if (isset($generalSetting->logo))
                        <img src="{{ asset('images/setting/general/' . $generalSetting->logo) }}"
                            alt="Institution Logo">
                    @endif
                    <h2>{{ $generalSetting->institute ?? '' }}</h2>
                    <p>{{ $generalSetting->salogan ?? '' }}</p>
                    <div class="contact-info">
                        <p>{{ $generalSetting->address ?? '' }}, {{ $generalSetting->phone ?? '' }}</p>
                        <p>{{ $generalSetting->email ?? '' }}, {{ $generalSetting->website ?? '' }}</p>
                    </div>
                </div>
            </div>
        @endif
    @else
        <div class="registration-unavailable">
            <h1>REGISTRATION NOT AVAILABLE AT THIS MOMENT</h1>
            <div class="institution-info">
                @if (isset($generalSetting->logo))
                    <img src="{{ asset('images/setting/general/' . $generalSetting->logo) }}" alt="Institution Logo">
                @endif
                <h2>{{ $generalSetting->institute ?? '' }}</h2>
                <p>{{ $generalSetting->salogan ?? '' }}</p>
                <div class="contact-info">
                    <p>{{ $generalSetting->address ?? '' }}, {{ $generalSetting->phone ?? '' }}</p>
                    <p>{{ $generalSetting->email ?? '' }}, {{ $generalSetting->website ?? '' }}</p>
                </div>
            </div>
        </div>
    @endif

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        // Tab navigation order
        const tabOrder = [
            'generalInfo',
            'academicInfo',
            'profileImage',
            @if(isset($data['annexures']) && count($data['annexures']) > 0)
                'annexure',
            @endif
            @if($data['registration_setting']->rules_status == '1')
                'rules',
            @endif
            @if($data['registration_setting']->agreement_status == '1')
                'agreement'
            @endif
        ];

        // Centralized navigation function
        function navigateTab(direction) {
            const currentTab = $('.tab-pane.active').attr('id');
            const currentIndex = tabOrder.indexOf(currentTab);

            if (direction === 'next' && validateTab(currentTab)) {
                if (currentIndex < tabOrder.length - 1) {
                    activateTab(tabOrder[currentIndex + 1]);
                }
            } else if (direction === 'prev') {
                if (currentIndex > 0) {
                    activateTab(tabOrder[currentIndex - 1]);
                }
            }
        }

        // Tab activation function
        function activateTab(tabName) {
            $('.tab-pane').removeClass('show active');
            $('#' + tabName).addClass('show active');
            $('.nav-tabs .nav-link').removeClass('active');
            $('a[href="#' + tabName + '"]').addClass('active');

            // Update navigation buttons
            updateNavigationButtons(tabName);

            // Scroll to top of the form
            $('html, body').animate({
                scrollTop: $('.registration-form-container').offset().top - 20
            }, 300);
        }

        // Update navigation buttons visibility
        function updateNavigationButtons(currentTab) {
            const currentIndex = tabOrder.indexOf(currentTab);
            const prevButton = $('.btn-prev');
            const nextButton = $('.btn-next');
            
            // Hide previous button on first tab
            prevButton.toggle(currentIndex !== 0);
            
            // Show/hide next button or submit button
            if (currentIndex === tabOrder.length - 1) {
                nextButton.hide();
                $('#add-student').show();
            } else {
                nextButton.show();
                $('#add-student').hide();
            }
        }

        // Validation function
        function validateTab(tabName) {
            let isValid = true;
            let firstInvalidField = null;

            switch (tabName) {
                case 'generalInfo':
                    // Required fields validation
                    const generalFields = [
                        { field: 'input[name="first_name"]', message: "Please enter first name" },
                        { field: 'input[name="last_name"]', message: "Please enter last name" },
                        { field: 'input[name="date_of_birth"]', message: "Please select date of birth" },
                        { field: 'select[name="gender"]', message: "Please select gender" },
                        { field: 'input[name="nationality"]', message: "Please enter nationality" },
                        { field: 'input[name="mobile_1"]', message: "Please enter mobile number" },
                        { field: 'input[name="address"]', message: "Please enter address" },
                        { field: 'input[name="state"]', message: "Please enter state" },
                        { field: 'input[name="country"]', message: "Please enter country" },
                        { field: 'input[name="father_first_name"]', message: "Please enter father's first name" },
                        { field: 'input[name="father_last_name"]', message: "Please enter father's last name" },
                        { field: 'input[name="mother_first_name"]', message: "Please enter mother's first name" },
                        { field: 'input[name="mother_last_name"]', message: "Please enter mother's last name" },
                        { field: 'select[name="batch"]', message: "Please select batch" },
                        { field: 'select[name="faculty"]', message: "Please select faculty/program" },
                        { field: 'select[name="semester"]', message: "Please select semester/section" }
                    ];

                    generalFields.forEach(field => {
                        const $element = $(field.field);
                        if (!$element.val()) {
                            toastr.warning(field.message, "Validation Error");
                            $element.addClass('is-invalid');
                            if (!firstInvalidField) firstInvalidField = $element;
                            isValid = false;
                        } else {
                            $element.removeClass('is-invalid');
                        }
                    });

                    // Guardian validation
                    const guardianIs = $('input[name="guardian_is"]:checked').val();
                    if (guardianIs === 'father_as_guardian' || guardianIs === 'mother_as_guardian' || 
                        guardianIs === 'other_guardian' || guardianIs === 'self_guardian') {
                        const guardianFields = [
                            { field: 'input[name="guardian_first_name"]', message: "Please enter guardian first name" },
                            { field: 'input[name="guardian_last_name"]', message: "Please enter guardian last name" },
                            { field: 'input[name="guardian_mobile_1"]', message: "Please enter guardian mobile number" },
                            { field: 'input[name="guardian_relation"]', message: "Please enter guardian relation" },
                            { field: 'input[name="guardian_address"]', message: "Please enter guardian address" }
                        ];

                        guardianFields.forEach(field => {
                            const $element = $(field.field);
                            if (!$element.val()) {
                                toastr.warning(field.message, "Validation Error");
                                $element.addClass('is-invalid');
                                if (!firstInvalidField) firstInvalidField = $element;
                                isValid = false;
                            } else {
                                $element.removeClass('is-invalid');
                            }
                        });
                    }
                    break;

                case 'academicInfo':
                    if (!$('#subjects_wrapper').children().length) {
                        toastr.warning("Please load subjects for the selected semester", "Validation Error");
                        isValid = false;
                    }
                    break;

                case 'profileImage':
                    if ($('input[name="student_main_image"]').prop('required') && !$('#student_main_image').val()) {
                        toastr.warning("Please upload a student photo", "Validation Error");
                        $('#student_main_image').addClass('is-invalid');
                        firstInvalidField = $('#student_main_image');
                        isValid = false;
                    } else {
                        $('#student_main_image').removeClass('is-invalid');
                    }
                    break;

                case 'rules':
                    if (!$('#agree_rules').is(':checked')) {
                        toastr.warning("Please agree to the rules and regulations", "Validation Error");
                        $('#agree_rules').addClass('is-invalid');
                        firstInvalidField = $('#agree_rules');
                        isValid = false;
                    } else {
                        $('#agree_rules').removeClass('is-invalid');
                    }
                    break;

                case 'agreement':
                    if (!$('#agree_terms').is(':checked')) {
                        toastr.warning("Please agree to the terms and conditions", "Validation Error");
                        $('#agree_terms').addClass('is-invalid');
                        firstInvalidField = $('#agree_terms');
                        isValid = false;
                    } else {
                        $('#agree_terms').removeClass('is-invalid');
                    }
                    break;
            }

            if (!isValid && firstInvalidField) {
                $('html, body').animate({
                    scrollTop: firstInvalidField.offset().top - 100
                }, 300);
            }

            return isValid;
        }

        // Form submission handler
        $('#validation-form').on('submit', function(e) {
            if (!validateTab($('.tab-pane.active').attr('id'))) {
                e.preventDefault();
                toastr.error("Please correct the errors before submitting", "Submission Error");
            }
        });

        // Image preview function
        function previewImage(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    $('#previewImage').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);

                var fileName = input.files[0].name;
                $(input).next('.custom-file-label').addClass("selected").html(fileName);
            }
        }

        // Initialize on page load
        $(document).ready(function() {
            activateTab('generalInfo');

            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1;
            var yyyy = today.getFullYear();

            if (dd < 10) dd = '0' + dd;
            if (mm < 10) mm = '0' + mm;

            $("input[name='reg_date']").val(yyyy + '-' + mm + '-' + dd);

            $('.custom-file-input').on('change', function() {
                let fileName = $(this).val().split('\\').pop();
                $(this).next('.custom-file-label').addClass("selected").html(fileName);
            });

            $('select[name="guardian_link_id"]').select2({
                placeholder: 'Select Guardian...',
                ajax: {
                    url: '{{ route('student.guardian-name-autocomplete') }}',
                    dataType: 'json',
                    delay: 250,
                    processResults: function(data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });

            $('#load-guardian-html-btn').click(function() {
                var guardians_id = $('select[name="guardian_link_id"]').val();
                if (!guardians_id) {
                    toastr.warning("Please, Find Guardian First.", "Warning");
                } else {
                    $('#guardian_wrapper').empty();
                    $.ajax({
                        type: 'POST',
                        url: '{{ route('student.guardianInfo-html') }}',
                        data: {
                            _token: '{{ csrf_token() }}',
                            id: guardians_id
                        },
                        success: function(response) {
                            var data = $.parseJSON(response);
                            if (data.error) {
                                toastr.warning(data.message, "warning");
                            } else {
                                $('#guardian_wrapper').append(data.html);
                            }
                        }
                    });
                }
            });

            $('.upper').keyup(function() {
                this.value = this.value.toUpperCase();
            });

            // Initialize navigation buttons
            updateNavigationButtons('generalInfo');
        });

        /*copy permanent address on temporary address*/
        function CopyAddress(f) {
            if (f.permanent_address_copier.checked == true) {
                f.temp_address.value = f.address.value;
                f.temp_state.value = f.state.value;
                f.temp_postal_code.value = f.postal_code.value;
            }
        }

        /*copy Father Detail on Guardian Detail*/
        function FatherAsGuardian(f) {
            document.getElementById('guardian-detail').style.display = 'block';
            document.getElementById('link-guardian-detail').style.display = 'none';
            addRequiredFieldInGuardian();
            if (f.guardian_is.value == 'father_as_guardian') {
                f.guardian_first_name.value = f.father_first_name.value;
                f.guardian_middle_name.value = f.father_middle_name.value;
                f.guardian_last_name.value = f.father_last_name.value;
                f.guardian_eligibility.value = f.father_eligibility.value;
                f.guardian_occupation.value = f.father_occupation.value;
                f.guardian_office.value = f.father_office.value;
                f.guardian_office_number.value = f.father_office_number.value;
                f.guardian_residence_number.value = f.father_residence_number.value;
                f.guardian_mobile_1.value = f.father_mobile_1.value;
                f.guardian_mobile_2.value = f.father_mobile_2.value;
                f.guardian_email.value = f.father_email.value;
                f.guardian_relation.value = "FATHER";
            }
        }

        /*copy Mother Detail on Guardian Detail*/
        function MotherAsGuardian(f) {
            document.getElementById('guardian-detail').style.display = 'block';
            document.getElementById('link-guardian-detail').style.display = 'none';
            addRequiredFieldInGuardian();
            if (f.guardian_is.value == 'mother_as_guardian') {
                f.guardian_first_name.value = f.mother_first_name.value;
                f.guardian_middle_name.value = f.mother_middle_name.value;
                f.guardian_last_name.value = f.mother_last_name.value;
                f.guardian_eligibility.value = f.mother_eligibility.value;
                f.guardian_occupation.value = f.mother_occupation.value;
                f.guardian_office.value = f.mother_office.value;
                f.guardian_office_number.value = f.mother_office_number.value;
                f.guardian_residence_number.value = f.mother_residence_number.value;
                f.guardian_mobile_1.value = f.mother_mobile_1.value;
                f.guardian_mobile_2.value = f.mother_mobile_2.value;
                f.guardian_email.value = f.mother_email.value;
                f.guardian_relation.value = "MOTHER";
            }
        }

        /*copy Self Detail on Guardian Detail*/
        function SelfGuardian(f) {
            document.getElementById('guardian-detail').style.display = 'block';
            document.getElementById('link-guardian-detail').style.display = 'none';
            addRequiredFieldInGuardian();
            if (f.guardian_is.value == 'self_guardian') {
                f.guardian_first_name.value = f.first_name.value;
                f.guardian_middle_name.value = f.middle_name.value;
                f.guardian_last_name.value = f.last_name.value;
                f.guardian_residence_number.value = f.home_phone.value;
                f.guardian_mobile_1.value = f.mobile_1.value;
                f.guardian_mobile_2.value = f.mobile_2.value;
                f.guardian_email.value = f.email.value;
                f.guardian_address.value = f.address.value;
                f.guardian_relation.value = "SELF";
            }
        }

        /*Blank Guardian Detail to Enter New*/
        function OtherGuardian(f) {
            document.getElementById('guardian-detail').style.display = 'block';
            document.getElementById('link-guardian-detail').style.display = 'none';
            addRequiredFieldInGuardian();
            if (f.guardian_is.value == 'other_guardian') {
                f.guardian_first_name.value = "";
                f.guardian_middle_name.value = "";
                f.guardian_last_name.value = "";
                f.guardian_eligibility.value = "";
                f.guardian_occupation.value = "";
                f.guardian_office.value = "";
                f.guardian_office_number.value = "";
                f.guardian_residence_number.value = "";
                f.guardian_mobile_1.value = "";
                f.guardian_mobile_2.value = "";
                f.guardian_email.value = "";
                f.guardian_relation.value = "";
            }
        }

        function linkGuardian() {
            document.getElementById('guardian-detail').style.display = 'none';
            document.getElementById('link-guardian-detail').style.display = 'block';
            removeRequiredFieldInGuardian();
        }

        function addRequiredFieldInGuardian() {
            $('input[name="guardian_first_name"]').attr('required', 'required');
            $('input[name="guardian_last_name"]').attr('required', 'required');
            $('input[name="guardian_mobile_1"]').attr('required', 'required');
            $('input[name="guardian_relation"]').attr('required', 'required');
            $('input[name="guardian_address"]').attr('required', 'required');
        }

        function removeRequiredFieldInGuardian() {
            $('input[name="guardian_first_name"]').removeAttr('required');
            $('input[name="guardian_last_name"]').removeAttr('required');
            $('input[name="guardian_mobile_1"]').removeAttr('required');
            $('input[name="guardian_relation"]').removeAttr('required');
            $('input[name="guardian_address"]').removeAttr('required');
        }

        function loadSemesters($this) {
            $.ajax({
                type: 'POST',
                url: '{{ route('student.find-semester') }}',
                data: {
                    _token: '{{ csrf_token() }}',
                    faculty_id: $this.value
                },
                success: function(response) {
                    var data = $.parseJSON(response);
                    if (data.error) {
                        toastr.warning(data.message, "Warning");
                    } else {
                        $('.semester').html('').append('<option value="0">Select Sem./Sec.</option>');
                        $.each(data.semester, function(key, valueObj) {
                            $('.semester').append('<option value="' + valueObj.id + '">' + valueObj
                                .semester + '</option>');
                        });
                    }
                }
            });
        }

        function loadSubject($this) {
            $('#subjects_wrapper').html('');
            var faculty = $('select[name="faculty"]').val();
            var semester = $('select[name="semester"]').val();

            if (faculty == 0) {
                toastr.info("Please, Select Faculty/Program/Class", "Info:");
                return false;
            }

            if (semester == 0) {
                toastr.info("Please, Select Sem./Sec.", "Info:");
                return false;
            }

            if (!semester) {
                toastr.warning("Please, Choose Semester.", "Warning");
            } else {
                $.ajax({
                    type: 'POST',
                    url: '{{ route('online-registration.find-subject') }}',
                    data: {
                        _token: '{{ csrf_token() }}',
                        faculty_id: faculty,
                        semester_id: semester
                    },
                    success: function(response) {
                        var data = $.parseJSON(response);
                        if (data.error) {
                            $('#subjects_wrapper').html('');
                            toastr.warning(data.error, "Warning:");
                        } else {
                            $('#subjects_wrapper').html('');
                            $('#subjects_wrapper').append(data.subjects);
                            toastr.info(data.success, "Info:");
                        }
                    }
                });
            }
            appendAcademicInfoRow(semester);
        }

        function appendAcademicInfoRow($semester) {
            $.ajax({
                type: 'POST',
                url: '{{ route('student.academicInfo-html') }}',
                data: {
                    _token: '{{ csrf_token() }}',
                    semester_id: $semester
                },
                success: function(response) {
                    var data = $.parseJSON(response);
                    if (!data.error) {
                        $('#academicInfo_wrapper').empty();
                        $('#academicInfo_wrapper').append(data.html);
                    }
                }
            });
        }
    </script>
</body>

</html>